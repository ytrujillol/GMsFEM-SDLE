
Run Original_GMsFEM, follow functions for coefficient, 
right hand side and boundary condtions.

Run GMsFEM_kappa_tilde for modified version with local 
eigenvalue problem with \tilde{kappa}

For other experimennts in the paper Generalized multiscale finite element methods (GMsFEM)
Y Efendiev, J Galvis, TY Hou, 
Journal of computational physics 251, 116-135, please write me
email at jcgavlisa@unal.edu.co.