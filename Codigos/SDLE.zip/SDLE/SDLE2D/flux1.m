function f = flux1(x)
 
f =(x)./(   (x.^2)+(1-x).^2  );
