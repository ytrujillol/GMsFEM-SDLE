function z=boundary_condition(x,y)

z=0;
%z=0;
%z=x+y

