function z=boundary_condition(x,y)


  z=1-(x/256);
%  N = length(x);
%  
%  for i=1:N
%      if x(i)==0
%          z(i)=1;
%      elseif x(i)==256;
%          z(i)=0;
%      end
%  end
% z=z'   
