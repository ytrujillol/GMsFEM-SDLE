
function y1=forcing(x1,x2)
y1=0*x1;
%y1=8*sin(x2*(2*pi))-4*x1.*(x1-1).*sin(x2*(2*pi))*(2*pi)^2;

%y1= abs(x1-0.5)+abs(x2-0.5)<.4;