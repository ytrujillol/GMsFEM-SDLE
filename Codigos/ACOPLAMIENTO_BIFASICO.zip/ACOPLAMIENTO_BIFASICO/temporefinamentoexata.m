function temporefinamentoexata

clear all
clc
clf
 t=10;
 dt = 10:20:130;

m = length(dt);
 
  for i = 1:m
 % t1=0;  t2=10;   t3=20;"Velocity Field"
 
     solexata(dt(i));
    % PRINCIPALSEMIBIFASICO2(t2);
     
  end
    
   
end